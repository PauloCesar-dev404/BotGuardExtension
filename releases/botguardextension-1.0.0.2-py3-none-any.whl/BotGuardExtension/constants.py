__author__ = "PauloCesar-dev404"
__lib__ = 'BotGuardExtension'
# (major, minor, patch, build)
__version_info__ = (1, 0, 0, 2)
__version__ = ".".join(str(num) for num in __version_info__)
__repo__ = f"https://github.com/PauloCesar-dev404/{__lib__}"
